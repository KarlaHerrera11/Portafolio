package com.example.proyecto009;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.net.PasswordAuthentication;

public class MainActivity extends AppCompatActivity {
    private EditText txtpnombre;
    private EditText txtppass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtpnombre = findViewById(R.id.txtpnombre);
        txtppass = findViewById(R.id.txtppass);
    }
    public void verificar (View view) {
        String nombre = txtpnombre.getText().toString();
        String contra = txtppass.getText().toString();
        if (nombre.equals("upsin") && contra.equals("123456")) {
             Intent intent = new Intent(this, principal.class);
            txtpnombre.setText("");
            txtppass.setText("");
             startActivity(intent);
        } else {
            String texto = "Contraseña Incorrecta";
            android.widget.Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
            txtpnombre.setText("");
            txtppass.setText("");
        }
    }
}